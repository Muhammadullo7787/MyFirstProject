import React from 'react';
import Card from './component/Card';

const arr = [
  {
    img: 'https://help.apple.com/assets/5FFC96D2F7B393613B23EED9/5FFC96D2F7B393613B23EEE0/en_US/a2c8dd21d7971197d0651e4ffdb89042.png',
    id: 1,
    title: '1 foto',
  },
  {
    img: 'https://help.apple.com/assets/5FFC96D2F7B393613B23EED9/5FFC96D2F7B393613B23EEE0/en_US/a2c8dd21d7971197d0651e4ffdb89042.png',
    id: 1,
    title: '2 foto',
  },
  {
    img: 'https://help.apple.com/assets/5FFC96D2F7B393613B23EED9/5FFC96D2F7B393613B23EEE0/en_US/a2c8dd21d7971197d0651e4ffdb89042.png',
    id: 3,
    title: '3 foto',
  },
  {
    img: 'https://help.apple.com/assets/5FFC96D2F7B393613B23EED9/5FFC96D2F7B393613B23EEE0/en_US/a2c8dd21d7971197d0651e4ffdb89042.png',
    id: 4,
    title: '4 foto',
  },
];

function App() {
  return (
    <div>
      <h1>SALOM</h1>
      <Card buy error id={true} list={arr} />
      <div style={{ padding: 5 }} />
      <Card buy id list={arr} />
      <div style={{ padding: 5 }} />
      <Card error list={arr} />
      <div style={{ padding: 5 }} />
      <Card list={arr} />
      <div style={{ padding: 5 }} />
      <Card list={arr} />
    </div>
  );
}

export default App;
